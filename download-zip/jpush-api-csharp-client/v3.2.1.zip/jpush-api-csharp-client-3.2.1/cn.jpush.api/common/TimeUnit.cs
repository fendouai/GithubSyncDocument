﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cn.jpush.api.common
{
    public enum TimeUnit
    {
        HOUR,
        DAY,
        WEEK,
        MONTH
    }
}
