﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cn.jpush.api.push.audience
{
    public enum AudienceType
    {
        tag,
        tag_and,
        alias,
        segment,
        registration_id
    }
}
