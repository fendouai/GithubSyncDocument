/**
 * Devices API features.
 * 
 * Url: https://device.jpush.cn/v3/devices
 */
package cn.jpush.api.device;
