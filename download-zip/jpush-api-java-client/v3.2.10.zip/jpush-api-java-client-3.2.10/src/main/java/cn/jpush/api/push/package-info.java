/**
 * Push API features.
 * 
 * Url: https://api.jpush.cn/v3/push
 */
package cn.jpush.api.push;