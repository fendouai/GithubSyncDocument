"""Python package for using the JPush API"""
from .conf import app_key, master_secret

__all__ = [
    app_key,
    master_secret,
]
