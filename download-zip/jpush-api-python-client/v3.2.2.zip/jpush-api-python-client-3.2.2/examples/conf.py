# please put your app_key and master_secret here
app_key = u'6be9204c30b9473e87bad4dc'
master_secret = u'9349ad7c90292a603c512e92'
