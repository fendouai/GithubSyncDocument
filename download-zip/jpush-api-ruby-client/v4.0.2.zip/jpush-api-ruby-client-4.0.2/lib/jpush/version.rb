module JPush
  VERSION = "4.0.2"
end
